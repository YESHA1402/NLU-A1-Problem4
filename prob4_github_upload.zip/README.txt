This baseline classifier distinguishes Sports and Politics text using keyword matching.
It serves as a simple rule-based method for comparison. More advanced approaches such as Naive Bayes and TF-IDF
can improve accuracy by learning from data rather than relying on fixed keywords.
